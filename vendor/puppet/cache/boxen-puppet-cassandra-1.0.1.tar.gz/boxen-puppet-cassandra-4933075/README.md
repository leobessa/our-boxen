# Cassandra Puppet Module for Boxen

## Usage

```puppet
include cassandra
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `java`
* `stdlib`

